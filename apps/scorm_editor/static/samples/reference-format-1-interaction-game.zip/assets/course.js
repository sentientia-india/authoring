const habits = [
  { text: "Ask for a simple explanation before writing your answer.", answer: "smart" },
  { text: "Copy generated text without checking it.", answer: "risky" },
  { text: "Create practice questions for revision.", answer: "smart" },
  { text: "Share private passwords or IDs with an AI tool.", answer: "risky" },
  { text: "Compare AI answers with trusted course material.", answer: "smart" }
];
const choices = {};
function renderHabits() {
  const container = document.getElementById("sort-activity");
  if (!container) return;
  container.innerHTML = habits.map((habit, index) => `
    <div class="habit" data-index="${index}">
      <span>${habit.text}</span>
      <button type="button" data-choice="smart">Smart use</button>
      <button type="button" data-choice="risky">Risky use</button>
    </div>`).join("");
}
function chooseHabit(index, value) {
  choices[index] = value;
  document.querySelectorAll(`[data-index="${index}"] button`).forEach(button => {
    button.classList.toggle("selected", button.textContent.toLowerCase().startsWith(value));
  });
}
function checkSort() {
  let score = 0;
  habits.forEach((habit, index) => { if (choices[index] === habit.answer) score += 1; });
  document.getElementById("sort-feedback").textContent = `You sorted ${score} of ${habits.length} habits correctly.`;
  if (score === habits.length) CourseScorm.setScore(40);
}
function buildPrompt() {
  const topic = document.getElementById("topic").value.trim() || "my topic";
  const level = document.getElementById("level").value.trim() || "my level";
  const task = document.getElementById("task").value.trim() || "explain clearly";
  document.getElementById("prompt-output").textContent =
    `Explain ${topic} in simple words for a ${level} learner. Please ${task}. Include 3 examples and one practice question.`;
}
function gradeQuiz() {
  const form = document.getElementById("quiz-form");
  const questions = ["q1", "q2", "q3"];
  const score = questions.reduce((total, name) => {
    const selected = form.querySelector(`input[name="${name}"]:checked`);
    return total + (selected && selected.value === "correct" ? 1 : 0);
  }, 0);
  const percent = Math.round((score / questions.length) * 100);
  document.getElementById("quiz-feedback").textContent = `Score: ${score}/${questions.length} (${percent}%).`;
  CourseScorm.setScore(percent);
  if (percent >= 67) CourseScorm.markComplete();
}
function markCourseComplete() {
  CourseScorm.markComplete();
  const footerMessage = document.querySelector("footer p");
  if (footerMessage) footerMessage.textContent = "Course marked complete. You can close this lesson.";
}
function bindStaticCourseControls() {
  renderHabits();
  const promptButton = document.getElementById("prompt-build");
  if (promptButton) promptButton.addEventListener("click", buildPrompt);
  const completeButton = document.getElementById("course-complete");
  if (completeButton) completeButton.addEventListener("click", markCourseComplete);
  const moduleCompleteButton = document.getElementById("module-complete");
  if (moduleCompleteButton) moduleCompleteButton.addEventListener("click", markCourseComplete);
  const sortActivity = document.getElementById("sort-activity");
  if (sortActivity && !sortActivity.dataset.bound) {
    sortActivity.dataset.bound = "true";
    sortActivity.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-choice]");
      if (!button) return;
      const habit = button.closest("[data-index]");
      if (!habit) return;
      chooseHabit(Number(habit.dataset.index), button.dataset.choice);
    });
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", bindStaticCourseControls);
} else {
  bindStaticCourseControls();
}
