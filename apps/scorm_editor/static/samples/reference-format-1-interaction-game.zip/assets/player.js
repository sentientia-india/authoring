const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}[ch]));

const TECHNICAL_UI_REPLACEMENTS = [
  ["SCORM course player", "Course overview"],
  ["SCORM", "course"],
  ["LMS", "learning platform"],
  ["source-aware", "course-based"],
  ["generated lessons", "lessons"],
  ["generated activities", "practice activities"],
  ["suspend/resume data", "saved progress"],
  ["suspend data", "saved progress"],
  ["course package", "course"],
  ["completion tracking", "progress tracking"],
  ["objective aligned", "Learning goal"],
  ["source aligned", "Based on course material"],
  ["expected learner decisions", "what to do in realistic situations"],
  ["LMS can capture", "Your progress saves"],
];

function learnerSafeText(value) {
  return TECHNICAL_UI_REPLACEMENTS.reduce(
    (text, pair) => text.replaceAll(pair[0], pair[1]),
    String(value ?? "")
  );
}

function flattenActivities(course) {
  return (course.modules || []).flatMap((module, moduleIndex) =>
    (module.activities || []).map((activity, activityIndex) => ({
      ...activity,
      moduleIndex,
      activityIndex,
      moduleTitle: module.title || `Module ${moduleIndex + 1}`,
    }))
  );
}

function flattenLessons(course) {
  return (course.modules || []).flatMap((module, moduleIndex) =>
    (module.lessons || []).map((lesson, lessonIndex) => ({
      ...lesson,
      moduleIndex,
      lessonIndex,
      moduleTitle: module.title || `Module ${moduleIndex + 1}`,
    }))
  );
}

function displayType(value) {
  return String(value || "interactive")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function lessonIdFor(moduleIndex, lessonIndex) {
  return `module-${moduleIndex + 1}-lesson-${lessonIndex + 1}`;
}

function findLessonById(course, lessonId) {
  for (const [moduleIndex, module] of (course.modules || []).entries()) {
    for (const [lessonIndex, lesson] of (module.lessons || []).entries()) {
      const id = lessonIdFor(moduleIndex, lessonIndex);
      if (id === lessonId) return { lesson, module, moduleIndex, lessonIndex, lessonId: id };
    }
  }
  return null;
}

function nextLessonId(course, activeLessonId) {
  const lessons = flattenLessons(course);
  const index = lessons.findIndex((lesson) => lessonIdFor(lesson.moduleIndex, lesson.lessonIndex) === activeLessonId);
  if (index < 0 || index >= lessons.length - 1) return null;
  const next = lessons[index + 1];
  return lessonIdFor(next.moduleIndex, next.lessonIndex);
}

function blockText(lesson, type) {
  return (lesson.content_blocks || []).find((block) => String(block.type || "").toLowerCase() === type)?.text || "";
}

function segmentText(value, maxLength = 360) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= maxLength) return text ? [text] : [];
  const sentences = text.split(/(?<=[.!?])\s+/);
  const segments = [];
  let current = "";
  sentences.forEach((sentence) => {
    if ((current + " " + sentence).trim().length > maxLength && current) {
      segments.push(current.trim());
      current = sentence;
    } else {
      current = `${current} ${sentence}`.trim();
    }
  });
  if (current) segments.push(current.trim());
  return segments.length ? segments : [text.slice(0, maxLength)];
}

function blockTitle(type) {
  const labels = {
    explanation: "Concept",
    concept: "Concept",
    example: "Workplace example",
    scenario: "Scenario",
    intro: "Context",
    practice: "Practice",
    summary: "Takeaway",
    takeaway: "Takeaway",
    checklist: "Checklist",
    source_note: "Source note",
  };
  return labels[String(type || "").toLowerCase()] || displayType(type || "lesson block");
}

function normalizeLessonDisplay(lesson) {
  const blocks = (lesson.content_blocks || []).filter((block) => block && block.text);
  const byType = {};
  blocks.forEach((block) => {
    const key = String(block.type || "concept").toLowerCase();
    if (!byType[key]) byType[key] = block;
  });
  const objective = lesson.objective || "Complete the lesson objective.";
  const sourceBlock = blocks.find((block) => (block.source_refs || []).length);
  return {
    hook: byType.intro || { type: "intro", text: `Start with the work situation this lesson prepares you for: ${objective}` },
    concept: byType.concept || byType.explanation || { type: "concept", text: objective },
    example: byType.example || { type: "example", text: "Use one real work example and decide what a good response would look like." },
    scenario: byType.scenario || { type: "scenario", text: "Imagine this issue appears during real work. Choose the next action before continuing." },
    practice: byType.practice || { type: "practice", text: "Write the action you would take, then compare it with the course standard." },
    takeaway: byType.takeaway || byType.summary || { type: "takeaway", text: "State the safest next step in one sentence." },
    sourceRefs: sourceBlock?.source_refs || [],
  };
}

function renderTextBlock(block, label) {
  const parts = segmentText(block.text);
  return `
    <section class="lesson-block">
      <strong>${escapeHtml(label || blockTitle(block.type))}</strong>
      ${parts.map((part) => `<p>${escapeHtml(part)}</p>`).join("")}
    </section>
  `;
}

function lessonBlocks(lesson) {
  const blocks = (lesson.content_blocks || []).filter((block) => block && block.text);
  if (blocks.length) return blocks;
  return [
    { type: "explanation", text: lesson.objective || "Review the lesson objective before completing this item." },
    { type: "example", text: "Use a realistic workplace example to connect this concept to a decision." },
    { type: "scenario", text: "Place the learner in a realistic situation and ask what should happen next." },
    { type: "practice", text: "Write the action you would take, then compare it with the course standard." },
    { type: "summary", text: "Finish by stating the safest next step in one sentence." },
  ];
}

function sourceLabel(lesson) {
  const refs = (lesson.content_blocks || []).flatMap((block) => block.source_refs || []);
  if (!refs.length) return "Based on course material";
  const ref = refs[0];
  return [ref.source_id, ref.reference].filter(Boolean).join(" / ") || "Based on course material";
}

function renderLessonReader(course, state, module, moduleIndex) {
  const active = state.activeLesson ? findLessonById(course, state.activeLesson) : null;
  if (!active || active.moduleIndex !== moduleIndex) return "";
  const lesson = active.lesson;
  const display = normalizeLessonDisplay(lesson);
  const blocks = [
    [display.hook, "Context"],
    [display.concept, "Key idea"],
    [display.example, "Worked example"],
    [display.scenario, "Guided scenario"],
    [display.takeaway, "Takeaway"],
  ];
  const practice = display.practice.text || blockText(lesson, "practice") || "Write the action you would take, then compare it with the course standard.";
  const completed = (state.completedLessons || []).includes(active.lessonId);
  const nextId = nextLessonId(course, active.lessonId);
  return `
    <article class="lesson-reader" data-reader-lesson-id="${active.lessonId}">
      <div class="lesson-reader-header">
        <span class="lesson-reader-kicker">${escapeHtml(module.title || `Module ${moduleIndex + 1}`)} lesson</span>
        <h3 class="lesson-reader-title">${escapeHtml(lesson.title || "Lesson")}</h3>
        <p class="lesson-reader-objective">${escapeHtml(lesson.objective || "Complete the lesson objective.")}</p>
        <div class="lesson-reader-meta">
          <span>${lesson.duration_minutes || 8} min</span>
          <span>${escapeHtml((lesson.objective_ids || []).length ? "Learning goal" : "Learning goal")}</span>
          <span>${escapeHtml(sourceLabel(lesson))}</span>
        </div>
      </div>
      <div class="lesson-block-grid">
        <div class="lesson-block-main">
          ${blocks.map(([block, label]) => renderTextBlock(block, label)).join("")}
        </div>
        <aside class="reader-side-panel">
          <div class="lesson-practice-card">
            <strong>Try it now</strong>
            ${segmentText(practice, 220).map((part) => `<p>${escapeHtml(part)}</p>`).join("")}
          </div>
          <div class="lesson-practice-card">
            <strong>Evidence note</strong>
            <p>${escapeHtml(sourceLabel(lesson))}</p>
          </div>
        </aside>
      </div>
      <div class="lesson-reader-actions">
        <button class="complete" type="button" data-reader-action="done">${completed ? "Completed" : "Mark done"}</button>
        ${nextId ? `<button class="secondary" type="button" data-reader-action="next" data-next-lesson-id="${nextId}">Next lesson</button>` : ""}
      </div>
    </article>
  `;
}

function loadState(course) {
  let scormState = {};
  try {
    const raw = CourseScorm.getSuspendData();
    if (raw && typeof raw === "object") scormState = raw;
  } catch (_error) {}
  const fallback = localStorage.getItem(`course-state:${course.course_slug}`);
  try {
    const localState = fallback ? JSON.parse(fallback) : {};
    return { ...scormState, ...localState };
  } catch (_error) {
    return scormState;
  }
}

function getEmbeddedCourseData() {
  const node = document.getElementById("course-data");
  if (!node || !node.textContent.trim()) return null;
  try {
    return JSON.parse(node.textContent);
  } catch (_error) {
    return null;
  }
}

function saveState(course, state) {
  try { CourseScorm.setSuspendData(state); } catch (_error) {}
  localStorage.setItem(`course-state:${course.course_slug}`, JSON.stringify(state));
}

function gameDefaults(state) {
  return {
    xp: Number(state.xp || 0),
    badges: Array.isArray(state.badges) ? state.badges : [],
    completedActivities: Array.isArray(state.completedActivities) ? state.completedActivities : [],
    quizScore: Number(state.quizScore || 0),
    quizPassed: Boolean(state.quizPassed),
  };
}

function awardBadge(game, badge) {
  if (!game.badges.includes(badge)) game.badges.push(badge);
}

function awardProgress(course, state, eventType, amount, badge) {
  const game = gameDefaults(state);
  game.xp += amount;
  if (badge) awardBadge(game, badge);
  if (game.xp >= 120) awardBadge(game, "Momentum Builder");
  const nextState = { ...state, ...game };
  saveState(course, nextState);
  renderGameCard(course, nextState);
  return nextState;
}

function renderGameCard(course, state) {
  const xp = document.getElementById("game-xp");
  const level = document.getElementById("game-level");
  const badges = document.getElementById("badge-row");
  const game = gameDefaults(state);
  if (xp) xp.textContent = `${game.xp} XP`;
  if (level) level.textContent = `Level ${Math.max(1, Math.floor(game.xp / 100) + 1)}`;
  if (badges) {
    const badgeNames = ["Course Starter", "Practice Pro", "Quiz Passed", "Course Complete"];
    badges.innerHTML = badgeNames.map((name) => `<span class="badge-pill ${game.badges.includes(name) ? "earned" : ""}">${escapeHtml(name)}</span>`).join("");
  }
}

function renderModuleNav(course, state) {
  const nav = document.getElementById("module-nav");
  if (!nav) return;
  nav.innerHTML = (course.modules || []).map((module, index) => `
    <li>
      <button class="module-nav-button" type="button" data-target="module-${index + 1}">
        ${escapeHtml(module.title || `Module ${index + 1}`)}
      </button>
    </li>
  `).join("");
  nav.querySelectorAll("button").forEach((button) => {
    button.addEventListener("click", () => {
      const target = document.getElementById(button.dataset.target);
      if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
      CourseScorm.setLocation(button.dataset.target);
      saveState(course, { ...state, activeModule: button.dataset.target });
    });
  });
}

function renderHero(course, state) {
  const title = document.getElementById("course-title");
  const lede = document.getElementById("course-lede");
  const progress = document.getElementById("progress-value");
  const duration = document.getElementById("stat-duration");
  const modules = document.getElementById("stat-modules");
  const lessons = document.getElementById("stat-lessons");
  if (title) title.textContent = course.course_title || "Course";
  if (lede) {
    lede.textContent = learnerSafeText(`Build practical skill in ${course.course_title || "this topic"} through ${course.modules.length} modules, ${flattenLessons(course).length} short lessons, practice activities, and a final check.`);
  }
  if (progress) progress.textContent = "0%";
  renderGameCard(course, state || {});
  if (duration) {
    const minutes = (course.modules || []).reduce((total, module) => total + Number(module.duration_minutes || 0), 0)
      || flattenLessons(course).reduce((total, lesson) => total + Number(lesson.duration_minutes || 0), 0);
    duration.textContent = minutes || "Short";
  }
  if (modules) modules.textContent = String((course.modules || []).length);
  if (lessons) lessons.textContent = String(flattenLessons(course).length);
}

function openLesson(course, state, lessonId) {
  const nextState = { ...state, activeLesson: lessonId };
  CourseScorm.setLocation(lessonId);
  saveState(course, nextState);
  renderCoursePlayer(course, nextState);
  const active = document.querySelector(`[data-reader-lesson-id="${lessonId}"]`) || document.querySelector(`[data-lesson-id="${lessonId}"]`);
  if (active) active.scrollIntoView({ behavior: "smooth", block: "start" });
}

function bindIntroControls(course, state) {
  const start = document.getElementById("start-course");
  const outline = document.getElementById("view-outline");
  if (start) {
    start.textContent = state.activeLesson ? "Continue learning" : "Start course";
    start.onclick = () => {
      const first = flattenLessons(course)[0];
      const lessonId = state.activeLesson || (first ? lessonIdFor(first.moduleIndex, first.lessonIndex) : null);
      if (lessonId) openLesson(course, state, lessonId);
    };
  }
  if (outline) {
    outline.onclick = () => {
      const deck = document.getElementById("lesson-deck");
      if (deck) deck.scrollIntoView({ behavior: "smooth", block: "start" });
    };
  }
}

function renderLessonCards(course, state, module, moduleIndex) {
  return `
    <div class="lesson-grid">
      ${(module.lessons || []).map((lesson, lessonIndex) => {
        const lessonId = lessonIdFor(moduleIndex, lessonIndex);
        const completed = (state.completedLessons || []).includes(lessonId);
        const current = state.activeLesson === lessonId;
        return `
          <article class="lesson-card ${completed ? "completed" : ""} ${current ? "active" : ""}" data-lesson-id="${lessonId}">
            <h3>${escapeHtml(lesson.title || `Lesson ${lessonIndex + 1}`)}</h3>
            <p>${escapeHtml(lesson.objective || "Complete the lesson objective.")}</p>
            <div class="lesson-meta">
              <span>${lesson.duration_minutes || 8} min</span>
              <span>${escapeHtml((lesson.objective_ids || []).length ? "Learning goal" : "Learning goal")}</span>
            </div>
            <div class="lesson-actions">
              <button class="primary" type="button" data-action="open">${current ? "Close" : "Open"}</button>
              <button class="secondary" type="button" data-action="done">${completed ? "Completed" : "Mark done"}</button>
            </div>
          </article>`;
      }).join("")}
    </div>
  `;
}

function renderModuleSection(course, state, module, moduleIndex) {
  return `
    <section class="course-panel" id="module-${moduleIndex + 1}">
      <div class="course-panel-header">
        <div>
          <h2 class="course-panel-title">${escapeHtml(module.title || `Module ${moduleIndex + 1}`)}</h2>
          <p class="course-panel-subtitle">${escapeHtml(`Module ${moduleIndex + 1} of ${course.modules.length}`)}</p>
        </div>
        <span class="lesson-meta">${(module.lessons || []).length} lessons</span>
      </div>
      ${renderLessonCards(course, state, module, moduleIndex)}
      ${renderLessonReader(course, state, module, moduleIndex)}
    </section>
  `;
}

function markLessonDone(course, state, lessonId) {
  const completedLessons = new Set(state.completedLessons || []);
  const wasNew = !completedLessons.has(lessonId);
  completedLessons.add(lessonId);
  const nextState = { ...state, activeLesson: lessonId, completedLessons: Array.from(completedLessons) };
  const awardedState = wasNew ? awardProgress(course, nextState, "lesson", 25, "Course Starter") : nextState;
  saveState(course, awardedState);
  CourseScorm.setLocation(lessonId);
  renderCoursePlayer(course, awardedState);
}

function markActivityComplete(course, state, activityId, points = 35) {
  const game = gameDefaults(state);
  if (!game.completedActivities.includes(activityId)) {
    game.completedActivities.push(activityId);
    game.xp += points;
    awardBadge(game, "Practice Pro");
    if (game.xp >= 120) awardBadge(game, "Momentum Builder");
  }
  const nextState = { ...state, ...game };
  saveState(course, nextState);
  renderGameCard(course, nextState);
  return nextState;
}

function renderLessonDeck(course, state) {
  const deck = document.getElementById("lesson-deck");
  if (!deck) return;
  const lessons = flattenLessons(course);
  deck.innerHTML = (course.modules || []).map((module, moduleIndex) => renderModuleSection(course, state, module, moduleIndex)).join("");

  deck.querySelectorAll("[data-lesson-id]").forEach((card) => {
    const lessonId = card.dataset.lessonId;
    const open = card.querySelector('[data-action="open"]');
    const done = card.querySelector('[data-action="done"]');
    if (open) {
      open.addEventListener("click", () => {
        const nextActiveLesson = state.activeLesson === lessonId ? null : lessonId;
        if (nextActiveLesson) {
          openLesson(course, state, nextActiveLesson);
        } else {
          const nextState = { ...state, activeLesson: null };
          CourseScorm.setLocation(lessonId);
          saveState(course, nextState);
          renderCoursePlayer(course, nextState);
        }
      });
    }
    if (done) {
      done.addEventListener("click", () => markLessonDone(course, state, lessonId));
    }
  });

  deck.querySelectorAll("[data-reader-action]").forEach((button) => {
    button.addEventListener("click", () => {
      const reader = button.closest("[data-reader-lesson-id]");
      const lessonId = reader?.dataset.readerLessonId;
      if (button.dataset.readerAction === "done" && lessonId) {
        markLessonDone(course, state, lessonId);
      }
      if (button.dataset.readerAction === "next" && button.dataset.nextLessonId) {
        const nextState = { ...state, activeLesson: button.dataset.nextLessonId };
        saveState(course, nextState);
        CourseScorm.setLocation(button.dataset.nextLessonId);
        renderCoursePlayer(course, nextState);
      }
    });
  });

  const completedCount = (state.completedLessons || []).length;
  const percent = lessons.length ? Math.round((completedCount / lessons.length) * 100) : 0;
  const progress = document.getElementById("progress-value");
  if (progress) progress.textContent = `${percent}%`;
}

function renderNativeActivity(activity, course, index, state) {
  const card = document.createElement("article");
  const activityId = activity.activity_id || `activity-${index}`;
  const completedActivity = gameDefaults(state).completedActivities.includes(activityId);
  card.className = `activity-card ${completedActivity ? "completed" : ""}`;
  const type = String(activity.activity_type || activity.type || "").toLowerCase();
  const items = activity.items || activity.cards || activity.steps || [];
  card.innerHTML = `
    <div class="activity-type">${escapeHtml(displayType(activity.activity_type || activity.type || "interactive"))}</div>
    <span class="activity-status">${completedActivity ? "Completed" : "+35 XP"}</span>
    <h3>${escapeHtml(activity.title || `Activity ${index + 1}`)}</h3>
    <p>${escapeHtml(activity.objective || activity.instructions || "Complete the interactive practice item.")}</p>
    <div class="activity-body"></div>
    <div class="activity-feedback" role="status"></div>
  `;
  const body = card.querySelector(".activity-body");
  const feedback = card.querySelector(".activity-feedback");
  if (type.includes("flashcard")) {
    const cards = items.length ? items : [
      { front: activity.objective || "Key idea", back: activity.instructions || "Explain it in your own words." },
    ];
    body.innerHTML = `<div class="flashcard-grid">
      ${cards.map((item, itemIndex) => `
        <button type="button" class="flashcard" data-card="${itemIndex}">
          <strong>${escapeHtml(item.front || item.term || item.prompt || `Card ${itemIndex + 1}`)}</strong>
          <span class="flashcard-back">${escapeHtml(item.back || item.definition || item.answer || "Review the course explanation.")}</span>
        </button>
      `).join("")}
    </div>`;
    body.querySelectorAll(".flashcard").forEach((button) => {
      button.addEventListener("click", () => {
        button.classList.toggle("is-flipped");
        feedback.textContent = "Flashcard flipped. Say the answer before revealing it.";
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 20);
        CourseScorm.recordInteraction?.(`activity-${index}`, "flashcard", button.textContent, "neutral", activity.title || "Flashcard");
      });
    });
  } else if (type.includes("accordion") || type.includes("tabs")) {
    const rows = items.length ? items : [
      { title: activity.objective || "Review point", detail: activity.instructions || "Open each item and connect it to the lesson." },
    ];
    body.innerHTML = `<div class="accordion-list">
      ${rows.map((item, itemIndex) => `
        <div class="accordion-item" data-accordion="${itemIndex}">
          <button type="button">${escapeHtml(item.title || item.label || item.front || `Item ${itemIndex + 1}`)}</button>
          <div class="accordion-panel">${escapeHtml(item.detail || item.text || item.back || "Review this point before continuing.")}</div>
        </div>
      `).join("")}
    </div>`;
    body.querySelectorAll(".accordion-item button").forEach((button) => {
      button.addEventListener("click", () => {
        const item = button.closest(".accordion-item");
        item.classList.toggle("is-open");
        feedback.textContent = "Section opened. Compare the detail with the lesson objective.";
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 20);
        CourseScorm.recordInteraction?.(`activity-${index}`, "accordion", button.textContent, "neutral", activity.title || "Accordion");
      });
    });
  } else if (type.includes("timeline")) {
    const rows = items.length ? items : [
      { label: "Learn", detail: "Read the core idea." },
      { label: "Practice", detail: "Apply it in a scenario." },
      { label: "Prove", detail: "Answer the assessment item." },
    ];
    body.innerHTML = `<div class="timeline-list">
      ${rows.map((item, itemIndex) => `
        <div class="timeline-item">
          <strong>${escapeHtml(item.label || item.title || `Step ${item.step || itemIndex + 1}`)}</strong>
          <span>${escapeHtml(item.detail || item.text || item.description || "Complete this step.")}</span>
        </div>
      `).join("")}
    </div>`;
    feedback.textContent = "Timeline ready. Move through the steps in order.";
  } else if (type.includes("roleplay") || type.includes("role-play")) {
    const persona = activity.persona || {};
    const roleName = persona.name || activity.persona_name || activity.role || "Scenario stakeholder";
    const roleTitle = persona.role || activity.persona_role || activity.counterpart_role || "Stakeholder";
    const goals = persona.goals || activity.goals || activity.objective || "Get a clear, safe, and useful response from the learner.";
    const constraints = persona.constraints || activity.constraints || "Push back when the learner is vague or skips the process.";
    const scenario = activity.situation || activity.scenario || activity.setup || "Practice the conversation using the lesson standard.";
    const objectives = activity.objectives || activity.expected_behaviors || [
      activity.objective || "Clarify the situation before acting.",
      "Use the documented process.",
      "Communicate the next step clearly.",
    ];
    const rubric = activity.rubric || objectives.map((objective, rubricIndex) => ({
      criterion: objective,
      points: rubricIndex === 0 ? 40 : 30,
    }));
    body.innerHTML = `
      <div class="roleplay-grid">
        <div class="roleplay-persona">
          <strong>${escapeHtml(roleName)} · ${escapeHtml(roleTitle)}</strong>
          <p>${escapeHtml(scenario)}</p>
          <p><b>Goal:</b> ${escapeHtml(goals)}</p>
          <p><b>Constraint:</b> ${escapeHtml(constraints)}</p>
        </div>
        <div class="roleplay-rubric">
          <strong>Success rubric</strong>
          <ul>
            ${rubric.map((item) => `<li>${escapeHtml(item.criterion || item.objective || item)} (${escapeHtml(item.points || item.weight || 1)} pts)</li>`).join("")}
          </ul>
        </div>
      </div>
      <label class="roleplay-response">
        <strong>Your response</strong>
        <span>${escapeHtml(objectives.join(" "))}</span>
        <textarea placeholder="Write what you would say or do in this role-play"></textarea>
      </label>
      <button type="button" class="primary">Score response</button>
    `;
    body.querySelector("button").addEventListener("click", () => {
      const response = body.querySelector("textarea").value.trim();
      const lower = response.toLowerCase();
      const hits = objectives.filter((objective) => {
        const terms = String(objective).toLowerCase().split(/\W+/).filter((term) => term.length > 5);
        return terms.some((term) => lower.includes(term));
      }).length;
      const score = objectives.length ? Math.max(25, Math.round((hits / objectives.length) * 100)) : 50;
      feedback.textContent = response
        ? `Debrief score: ${score}%. Check your answer against the rubric before continuing.`
        : "Write a response first, then score it against the rubric.";
      if (response) {
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 45);
      }
      CourseScorm.recordInteraction?.(`activity-${index}`, "roleplay", response, score >= 70 ? "correct" : "neutral", activity.title || "Role-play");
    });
  } else if (type.includes("fill")) {
    const prompt = activity.prompt || activity.objective || "Complete the missing term.";
    const answer = String(activity.answer || activity.correct_answer || activity.correct || "").trim().toLowerCase();
    body.innerHTML = `
      <div class="fill-blank-row">
        <label>${escapeHtml(prompt)}<input type="text" autocomplete="off"></label>
        <button type="button" class="primary">Check answer</button>
      </div>
    `;
    body.querySelector("button").addEventListener("click", () => {
      const value = body.querySelector("input").value.trim().toLowerCase();
      const correct = answer ? value === answer : value.length > 2;
      feedback.textContent = correct ? "Accepted. Continue to the next item." : "Not yet. Recheck the lesson wording and try again.";
      if (correct) {
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 35);
      }
      CourseScorm.recordInteraction?.(`activity-${index}`, "fill-in", value, correct ? "correct" : "wrong", activity.title || "Fill in the blank");
    });
  } else if (type.includes("matching")) {
    body.innerHTML = (items || []).map((item, itemIndex) => `
      <div class="match-row" data-item="${itemIndex}">
        <span>${escapeHtml(item.left || item.front || item.prompt || `Item ${itemIndex + 1}`)}</span>
        <button type="button" class="secondary">Reveal</button>
        <span class="match-result"></span>
      </div>
    `).join("");
    body.querySelectorAll(".match-row button").forEach((button) => {
      button.addEventListener("click", () => {
        const row = button.closest(".match-row");
        const result = row.querySelector(".match-result");
        const itemIndex = Number(row.dataset.item);
        const item = items?.[itemIndex] || {};
        result.textContent = item.right || item.back || item.match || "Matched";
        button.textContent = "Revealed";
        feedback.textContent = "Match revealed. Compare the pair before moving on.";
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 30);
        CourseScorm.recordInteraction?.(`activity-${index}`, "matching", item.left || item.front || item.prompt || "", "correct", activity.title || "Matching");
      });
    });
  } else if (type.includes("scenario") || type.includes("decision")) {
    const scenarioItem = items.find((item) => item && (item.choices || item.options)) || {};
    const choices = activity.choices || activity.options || scenarioItem.choices || scenarioItem.options || ["Choose the safest action", "Choose the fastest action", "Skip the check"];
    body.innerHTML = `
      <p class="scenario-prompt">${escapeHtml(scenarioItem.scenario || activity.scenario || "Choose the best response for this workplace situation.")}</p>
      <div class="scenario-options">
        ${choices.map((choice, choiceIndex) => `<button type="button" class="primary" data-choice="${choiceIndex}">${escapeHtml(choice.label || choice.text || choice)}</button>`).join("")}
      </div>
      <div class="scenario-consequence" hidden></div>
    `;
    body.querySelectorAll("button").forEach((button) => {
      button.addEventListener("click", () => {
        body.querySelectorAll("button").forEach((item) => item.classList.remove("is-selected"));
        button.classList.add("is-selected");
        const choice = choices[Number(button.dataset.choice)] || {};
        const result = choice.feedback || choice.consequence || choice.result || "Compare this decision with the lesson standard before continuing.";
        const consequence = body.querySelector(".scenario-consequence");
        consequence.hidden = false;
        consequence.textContent = result;
        feedback.textContent = `Decision saved: ${button.textContent}.`;
        card.classList.add("completed");
        card.querySelector(".activity-status").textContent = "Completed";
        state = markActivityComplete(course, state, activityId, 35);
        CourseScorm.recordInteraction?.(`activity-${index}`, "choice", button.textContent, choice.result === "risk" ? "wrong" : "neutral", activity.title || "Scenario");
      });
    });
  } else if (type.includes("reflection")) {
    body.innerHTML = `
      <label class="reflection-box">
        <span>Your reflection</span>
        <textarea rows="4" placeholder="Write your answer here"></textarea>
      </label>
      <button type="button" class="primary">Save reflection</button>
    `;
    body.querySelector("button").addEventListener("click", () => {
      feedback.textContent = "Reflection saved in this session.";
      card.classList.add("completed");
      card.querySelector(".activity-status").textContent = "Completed";
      state = markActivityComplete(course, state, activityId, 25);
      CourseScorm.setSuspendData({ ...state, [`reflection-${index}`]: body.querySelector("textarea").value });
    });
  } else {
    body.innerHTML = `
      <label class="reflection-box">
        <span>Action commitment</span>
        <textarea rows="3" placeholder="Write the action you would take after this lesson"></textarea>
      </label>
      <button type="button" class="primary">Save action</button>
    `;
    body.querySelector("button").addEventListener("click", () => {
      feedback.textContent = "Action saved. Use it as your next workplace practice step.";
      card.classList.add("completed");
      card.querySelector(".activity-status").textContent = "Completed";
      state = markActivityComplete(course, state, activityId, 25);
      CourseScorm.setSuspendData({ ...state, [`activity-action-${index}`]: body.querySelector("textarea").value });
    });
  }
  return card;
}

function renderActivityDeck(course, state) {
  const deck = document.getElementById("activity-deck");
  if (!deck) return;
  const activities = flattenActivities(course);
  deck.innerHTML = "";
  const shell = document.createElement("div");
  shell.className = "activity-shell";
  activities.forEach((activity, index) => {
    shell.appendChild(renderNativeActivity(activity, course, index, state));
  });
  if (!activities.length) {
    shell.innerHTML = "<p>No interactive activities were generated for this course.</p>";
  }
  deck.appendChild(shell);
}

function renderAssessmentOrEmptyState(course) {
  const deck = document.getElementById("assessment-deck");
  if (!deck) return;
  const questions = course.final_assessment?.questions || [];
  if (!questions.length) {
    deck.innerHTML = "";
    return;
  }
  const stored = loadState(course);
  if (stored.quizSubmitted) {
    renderQuizResult(course, deck, stored);
    return;
  }
  const activeQuestion = Number(stored.activeQuestion || 0);
  deck.innerHTML = `
    <div class="course-panel">
      <div class="course-panel-header">
        <div>
          <h2 class="course-panel-title">${escapeHtml(course.final_assessment?.title || "Final Check")}</h2>
          <p class="course-panel-subtitle">Check your understanding before completing the course.</p>
        </div>
      </div>
      <form id="quiz-form">
        ${questions.map((question, index) => `
          <fieldset class="quiz-question-card ${index === activeQuestion ? "" : "is-hidden"}" data-question-index="${index}">
            <div class="quiz-progress-text">Question ${index + 1} of ${questions.length}</div>
            <legend>${escapeHtml(question.question || "Question")}</legend>
            ${(question.options || []).map((option, optionIndex) => `
              <label>
                <input type="radio" name="q${index}" value="${escapeHtml(option)}">
                ${escapeHtml(option)}
              </label>
            `).join("")}
          </fieldset>
        `).join("")}
      </form>
      <div class="assessment-nav">
        <button class="secondary" type="button" id="quiz-prev" ${activeQuestion <= 0 ? "disabled" : ""}>Previous</button>
        <button class="secondary" type="button" id="quiz-next" ${activeQuestion >= questions.length - 1 ? "disabled" : ""}>Next question</button>
      </div>
      <div class="assessment-actions">
        <button class="primary" type="button" id="quiz-submit">Submit final check</button>
        <p id="quiz-feedback" class="feedback" role="status"></p>
      </div>
    </div>
  `;
  deck.querySelectorAll("fieldset label").forEach((label) => {
    label.addEventListener("click", () => {
      label.closest("fieldset").querySelectorAll("label").forEach((item) => item.classList.remove("is-selected"));
      label.classList.add("is-selected");
    });
  });
  const submit = deck.querySelector("#quiz-submit");
  const feedback = deck.querySelector("#quiz-feedback");
  const setQuestion = (nextIndex) => {
    const safeIndex = Math.max(0, Math.min(questions.length - 1, nextIndex));
    const nextState = { ...loadState(course), activeQuestion: safeIndex };
    saveState(course, nextState);
    renderAssessmentOrEmptyState(course);
  };
  deck.querySelector("#quiz-prev")?.addEventListener("click", () => setQuestion(activeQuestion - 1));
  deck.querySelector("#quiz-next")?.addEventListener("click", () => setQuestion(activeQuestion + 1));
  if (!submit) return;
  submit.addEventListener("click", () => {
    const form = deck.querySelector("#quiz-form");
    let score = 0;
    questions.forEach((question, index) => {
      const selected = form.querySelector(`input[name="q${index}"]:checked`);
      if (selected && (question.correct_answers || []).includes(selected.value)) score += 1;
      CourseScorm.recordInteraction?.(`quiz-${index}`, question.type || "mcq", selected ? selected.value : "", selected && (question.correct_answers || []).includes(selected.value) ? "correct" : "wrong", question.question || "");
    });
    const percent = questions.length ? Math.round((score / questions.length) * 100) : 0;
    const game = gameDefaults(loadState(course));
    game.quizScore = percent;
    game.quizPassed = percent >= 80;
    game.quizSubmitted = true;
    game.xp += score * 20;
    if (game.quizPassed) awardBadge(game, "Quiz Passed");
    const nextState = { ...loadState(course), ...game };
    saveState(course, nextState);
    CourseScorm.setScore(percent);
    if (percent >= 80) CourseScorm.markComplete();
    feedback.textContent = `Score: ${score}/${questions.length} (${percent}%).`;
    renderGameCard(course, nextState);
    renderQuizResult(course, deck, nextState);
  });
}

function renderQuizResult(course, deck, state) {
  const score = Number(state.quizScore || 0);
  const passed = score >= 80;
  deck.innerHTML = `
    <div class="quiz-result-card">
      <p class="eyebrow">${passed ? "Final check passed" : "Review and try again"}</p>
      <h2>${passed ? "You passed the final check" : "You can improve this score"}</h2>
      <div class="quiz-score">${score}%</div>
      <p>${passed ? "Your completion is ready. Review your badges or finish the course." : "Review the lesson cards, then retry the final check."}</p>
      <div class="hero-actions">
        <button class="secondary" type="button" id="quiz-retry">Try again</button>
        ${passed ? '<button class="complete" type="button" id="show-completion">Complete course</button>' : ""}
      </div>
    </div>
  `;
  const retry = deck.querySelector("#quiz-retry");
  if (retry) {
    retry.addEventListener("click", () => {
      const nextState = { ...state, quizSubmitted: false };
      saveState(course, nextState);
      renderAssessmentOrEmptyState(course);
    });
  }
  const completion = deck.querySelector("#show-completion");
  if (completion) {
    completion.addEventListener("click", () => renderCompletionScreen(course, state));
  }
}

function renderCompletionScreen(course, state) {
  const deck = document.getElementById("assessment-deck");
  if (!deck) return;
  const lessons = flattenLessons(course);
  const completed = (state.completedLessons || []).length;
  const game = gameDefaults(state);
  awardBadge(game, "Course Complete");
  const nextState = { ...state, ...game, courseCompleted: true };
  saveState(course, nextState);
  CourseScorm.markComplete();
  renderGameCard(course, nextState);
  deck.innerHTML = `
    <section class="completion-screen">
      <p class="eyebrow">Course complete</p>
      <h2>${escapeHtml(course.course_title || "Course")}</h2>
      <div class="completion-score">${Number(nextState.quizScore || 0)}%</div>
      <div class="completion-grid">
        <div><strong>${completed}/${lessons.length}</strong><span>Lessons complete</span></div>
        <div><strong>${nextState.xp}</strong><span>XP earned</span></div>
        <div><strong>Ready</strong><span>Certificate status</span></div>
      </div>
      <p>Your completion is saved. You can close this course or review any lesson again.</p>
      <button class="secondary" type="button" id="return-outline">Return to course outline</button>
    </section>
  `;
  deck.querySelector("#return-outline").addEventListener("click", () => {
    document.getElementById("lesson-deck")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

function renderModulePage(course) {
  const moduleIndex = Math.max(0, Number(document.body.dataset.modulePage || "1") - 1);
  const module = course.modules[moduleIndex] || course.modules[0];
  const deck = document.getElementById("module-activity-deck");
  if (!deck || !module) return;
  const activities = module.activities || [];
  deck.innerHTML = `
    <div class="course-panel">
      <div class="course-panel-header">
        <div>
          <h2 class="course-panel-title">${escapeHtml(module.title || `Module ${moduleIndex + 1}`)}</h2>
          <p class="course-panel-subtitle">${activities.length} module activities</p>
        </div>
        <a class="primary" href="index.html" style="text-decoration:none; display:inline-flex; align-items:center;">Back to course</a>
      </div>
      <div class="activity-shell">
        ${activities.map((activity, index) => `
          <article class="activity-card">
            <div class="activity-type">${escapeHtml(activity.activity_type || activity.type || "interactive")}</div>
            <h3>${escapeHtml(activity.title || `Activity ${index + 1}`)}</h3>
            <p>${escapeHtml(activity.objective || activity.instructions || "Complete the module activity.")}</p>
          </article>
        `).join("")}
      </div>
    </div>
  `;
}

function renderCoursePlayer(course, providedState) {
  const state = providedState || loadState(course);
  renderHero(course, state);
  renderModuleNav(course, state);
  renderLessonDeck(course, state);
  bindIntroControls(course, state);
  renderActivityDeck(course, state);
  renderAssessmentOrEmptyState(course);
  if (state.activeLesson) {
    const active = document.querySelector(`[data-lesson-id="${state.activeLesson}"]`);
    if (active) active.classList.add("active");
  }
}

async function bootCoursePlayer() {
  const root = document.querySelector("[data-course-player], [data-module-page]");
  if (!root) return;
  let course = getEmbeddedCourseData();
  if (!course) {
    const response = await fetch("data/course.json");
    course = await response.json();
  }
  document.body.dataset.theme = course.theme || "studio";
  if (document.body.dataset.coursePlayer !== undefined) {
    renderCoursePlayer(course);
    return;
  }
  if (document.body.dataset.modulePage) {
    renderModulePage(course);
  }
}

bootCoursePlayer();
